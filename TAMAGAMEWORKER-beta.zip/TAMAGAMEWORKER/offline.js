﻿{
	"version": 1541966926,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"images/accept-sheet0.png",
		"images/giveclean-sheet0.png",
		"images/reject-sheet0.png",
		"images/tamagotcha-sheet0.png",
		"images/title-sheet0.png",
		"images/bossmessage-sheet0.png",
		"images/angrywork-sheet0.png",
		"images/tama-sheet0.png",
		"images/tama-sheet1.png",
		"images/tama-sheet2.png",
		"images/sleepbar-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"events.json"
	]
}